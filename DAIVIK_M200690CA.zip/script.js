// window.addEventListener("scroll", function() {showFunction()});

// function showFunction() {
//     if (document.body.scrollTop > 900 || document.documentElement.scrollTop > 900) {
//         document.getElementById("everything-at-once").style.display = "block";
//     } else {
//         document.getElementById("everything-at-once").style.display = "none";
//     }
// }